# Archivos de la carpeta _data

Para Jekyll, la carpeta `_data` se utiliza para definir datos extra que pueden usarse para la construccion automatica de las vistas. 

En este proyecto la carpeta `_data` contiene 9 archivos csv y 1 yml. Son los siguientes:

- [navigation.yml](#navigationyml)
- [proyectos.csv](#proyectoscsv)
- [repositorio.csv](#repositoriocsv)
- [instituciones.csv](#institucionescsv)
- [investigadores.csv](#investigadorescsv)
- [proyectos_fechas_actualizacion.csv](#proyectos_fechas_actualizacioncsv)
- [estados.csv](#estadoscsv)
- [municipios.csv](#municipioscsv)
- [paises.csv](#paisescsv)
- [zonas_metropolitanas.csv](#zonas_metropolitanascsv)

## navigation.yml
Define la estructura de navegacion del sitio, las secciones disponibles pueden agruparse en submenus y ademas poner links externos

- `name` nombre de la seccion
- `link` path relativo a la pagina de inicio, si *external:true* debe ser un url completo 
- `external` si tiene el valor *true* expresa que el link es externo, es decir que no forma parte del sitio. El link se abrira en otra pestaña. Cualquier otro valor o si no se define se asume que es falso.
- `is_submenu` si tiene el valor *1* expresa que este elemento se interpretara como un submenu de navegacion. Cualquier otro valor o si no se define esta propiedad asume que no es un submenu.
- `items` si tiene el *is_submenu:1* esta propiedad es obligatoria. Define un array de todos los elementos que integraran el submenu. Cada elemento debera contener por lo menos las propiedades *name* y *link*


## proyectos.csv
Permite indexar los proyectos dentro del micrositio, tiene asociacion directa con `investigadores.csv`, `proyectos_fecha_actualizacion.csv` e `instituciones.csv`, es decir el id de cada proyecto puede tener  referencia en un investigador o una institucion.

- `c` (no se usa) un campo comodin al inicio, ya que jekyll aveces no logra leer el primer campo
- `orden` *int* define el orden en el que aparecen en la seccion de proyectos.
- `portada` imagen del proyecto con extención e.j. ` ama.png `
- `id` *string* identificador unico del proyecto
- `nombre` el nombre del proyecto
- `categoria` la cateforia en la que entra el proyectos, por ahora disponibles: Modelos Matemáticos, Análisis Geográficos, Tableros Informativos, Repositorios
- `instituciones` lista de las instituaciones que participaron en el proyecto 
- `investigadores`lista de los investigadores que participaron en el proyecto 
- `tecnicos` lista de los investigadores que tuvieron un rol tecnico dentro del proyecto 
- `descripcion` Breve descripcion del proyecto, es el parrafo que aparece en cada pagina de proyecto.

___
NOTA:
Existe un proyecto vacío `atencion_hospitalaria`, pero como se requiere que exista el id para completar la url del reporte, no lo quiten! y no olviden como yo, agregar un proyecto aunque no exista mas que su reporte!!! (つ﹏⊂) 
___


## repositorio.csv
Contiene la lista de documentos para la seccion de productos de investigación,  tiene asociacion directa con `investigadores.csv` y `proyectos.csv`,es decir, un producto de investigacion puede tener referencia con un investigador o un proyecto.

- `orden` *int* orden inverso en el que la caja de productos se ordena en la vista, incrementar cada que exista un `area` nueva (requerido por accesibilidad, aunque se reordenen en css los componentes en una vista, deben estar organizados en el mismo orden para cuando un usuario navega a traves del teclado)
- `area` *string* *sin espacios ni caracteres especiales* para organizar las secciones, da nombre a las clases en la vista y a las imagenes que utiliza de portada, es un nombre clave basado en el titulo
- `id` *int* identificador del reporte o archivo, importante que sea autoincremental
- `fecha` *dd/mm/yyyy* la fecha en la que se publica el reporte
- `tipo` El tipo de documento que se publica, (aparece en el link de descarga del documento)
- `proyecto` El proyecto al que pertencece, debe estar dado de alta en el archvo `proyectos.csv`
- `autores` (actualmente no se esta desplegando en el sitio) los identificadores de los investigadores que estan dados de alta en `investigadores.csv`
- `archivo` el nombre del archivo, debe estar contenido en una carpeta como la siguiente */productos/{id_proyecto}/*
- `titulo` el titulo del documento, tambien sirve para agrupar en distintos secciones los documentos, es decir, los recuadros o secciones en las que se agrupan los reportes
- `descripcion` (Actualmente no se esta desplegando) Una descripcion muy corta del documento

### tabla de areas con orden y título
| orden | area | titulo |
|-------|------|--------|
| 15 | amma3 | Modelo AMMA-3 Informe |
| 14 | metodologiatendencia | Metodología para el análisis de tendencias de curvas epidémicas de casos nuevos y decesos nuevos asociados a síndrome |
| 3 | rtincertidumbre | Filtering and improved Uncertainty Quantification in the dynamic estimation of effective reproduction numbers |
| 13 | tendencia | Tendencias de Curvas Epidémicas de Casos Nuevos y Mortalidad de COVID-19 |
| 12 | rtmovilidad | Predicción de R(t) usando movilidad |
| 11 | hospitalaria | Tiempo de atención hospitalaria, por jurisdicción sanitaria, ante Covid-19 |
| 10 | movilidad2 | Medición de Movilidad-2 usando Facebook, Google y Twitter. Informe 2 |
| 9 | movilidad | Medición de Movilidad usando Facebook, Google y Twitter |
| 8 | rt | Estimaciones de la Tasa de Reproducción Efectiva Rt de COVID-19 para los Estados y Zonas Metropolitanas de México |
| 7 | gompertz2 | Estimaciones del Modelo Gompertz-2 para los Estados y Zonas Metropolitanas de México |
| 6 | gompertz | Estimaciones del Modelo Gompertz para los Estados y Zonas Metropolitanas de México |
| 5 | ama2 | Modelo AMA-2 Informe |
| 4 | ama | Modelo AMA Informe |
| 3 | forecasting | Forecasting hospital demand during COVID-19 pandemic outbreaks |
| 2 | zonametropolitana | Informe Especial sobre La ZM del Valle de México |
| 1 | retrospectivo | Informe Especial Retrospectivo al 2020-04-15 |
| 0 | vulnerabilidad | Índice de Vulnerabilidad Municipal a COVID-19 |



## instituciones.csv
Permite indexar a las instituciones que participan en los proyectos, tiene asociacion directa con `investigadores.csv` y `proyectos.csv`, es decir el id de cada institucion puede tener una referencia en un investigador o un proyecto.

- `orden` el orden de aparicion dentro de la pagina que los indexe
- `id` el identificador con de cada institucion (datasets como investigadores.csv o proyectos csv hacen referencia a una institucion con este identificador)
- `institucion` nombre corto de la institucion
- `madre` Organismo o institucion madre de la que se desprende 
- `nombre` Nombre completo de la institución
- `descripcion` breve descripcion de lo que es la institución
- `link` el link al sitio web de la institucion


## investigadores.csv
Permite indexar la informacion de los investigadores  que participan en los proyectos, tiene asociacion directa con `repositorios.csv` y `proyectos.csv`, es decir el id de cada investigador puede tener una referencia en un producto de investigacion o en algun proyecto.

- `orden` el orden de aparicion dentro de  las paginas que los indexen
- `id` el identificador unico de cada investigador
- `institucion` el id de la institucion a la que pertenece, debe coincidir con el id del archivo instituciones.csv
- `nombre` el nombre del investigador
- `apellido_paterno` el apelliido paterno del investigador
- `apellido_materno` el apellido materno del investigador
- `rol` el rol del investigador dentro de su institucion
- `link` define si el investigador tiene pagina propia dentro del micrositio **1**: si tiene pagina propia, **0**: no tiene pagina propia
- `puesto` el puesto dentro de su institucion
- `proyectos` identificador de uno o mas proyectos en los que participa 


## proyectos_fechas_actualizacion.csv
Se describe la fecha en la que el proyecto se actualizo, se utiliza para desplegar las fechas de actualizacion en las visualizaciones.

- `proyecto` Identificador del proyecto o subproyecto (no coincide con `proyectos.csv`), es importante revisar en que parte se esta desplegando este identificador
- `fecha` Fecha en el formato `29 de octubre de 2020`, si el dia es menor a 10 debe contener un cero para que sea de dos digitos.


## estados.csv
Diccionario de estados de la republica.
Permite generar las listas de estados en varias partes del micrositio donde es necesario.

* `id` a dos digitos empezando con 01
* `nombre` nombre del estado
* `ama` variación del nombre del estado para gráficas AMA
* `gompertz` variación del nombre del estado para gráficas Gompertz
* `abrev` abreviatura del nombre del estado a tres digitos
* `obs_ama` notas del modelo AMA que se agregan a las gráficas (se obtienen de los reportes de los investigadores).
* `obs_gz` notas del modelo Gompertz que se agregan a las gráficas (se obtienen de los reportes de los investigadores).


## municipios.csv
Diccionario de municipios de la republica

- `id` identificador del municipio, es equivalente a la clave geoestadistica que proporciona INEGI
- `nombre` nombre completo del municipio
- `abrev` nombre del municipio truncado a 8 caracteres


## paises.csv
Diccionanrio de paises, por el momento solo se usa

- `ISO3` Abreviacion en 3 caracateres del pais
- `NAME` Nombre del pais

---
Fecha de actualizacion 18/nov/2020
