# -*- coding: utf-8 -*-

import random

"""	Title: Presos Ingresados
"""

for i in range(1, 16):
	print("Día", i, "Nº de presos:", random.randint(0,100))