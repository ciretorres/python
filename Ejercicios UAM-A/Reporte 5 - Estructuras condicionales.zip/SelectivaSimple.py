# -*- coding: utf-8 -*-
"""
	Tema: Estructura condicional selectiva simple
	Autor: Eric
	UEA: Introduccion a la programacion
	Profesora: Dra. Lizbeth Gallardo Lopez

	Fecha: 27/05/2019
"""

a = 8

if a != 8:
	print("a es diferente de 8")

print("\nChao!")