# -*- coding: utf-8 -*-
"""
	Tema: Estructura condicional selectiva doble
	Autor: Eric
	UEA: Introduccion a la programacion
	Profesora: Dra. Lizbeth Gallardo Lopez

	Fecha: 27/05/2019
"""

dia = 7

if dia != 7:
	print("Hoy no es domingo.\nHoy tienes que trabajar!")
else:
	print("Hoy es domingo.\nHay que jugar videojuegos!")