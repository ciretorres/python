# -*- coding: utf-8 -*-
"""
	Tema: Estructura condicional repetitiva for
	Autor: Eric
	UEA: Introduccion a la programacion
	Profesora: Dra. Lizbeth Gallardo Lopez

	Fecha: 27/05/2019
"""

print("Ejemplificado la estructura condicional repetitiva For.")

n = int(input("¿Cuántas veces quieres iterar?\n: "))

for x in range(n):
	print(x)

print("Ya terminé de iterar!")