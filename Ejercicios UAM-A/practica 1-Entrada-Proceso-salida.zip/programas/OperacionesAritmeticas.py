# Tema: Operaciones aritmeticas
# Autor: Eric Torres Velasco
# UEA: Introduccion a la programacion
# Profesora: Dra. Lizbeth Gallardo Lopez
# Fecha: 26/01/2019

print("Ingresa dos valores enteros \nValor 1: ")

valor1 = input()

print("Valor 2: ")

valor2 = input()

print('Suma: ', valor1 + valor2)
print("Resta: ", valor1 - valor2)
print("Multiplicacion: ", valor1 * valor2)