# Tema: Area de un circulo
# Autor: Eric Torres Velasco
# UEA: Introduccion a la programacion
# Profesora: Dra. Lizbeth Gallardo Lopez
# Fecha: 26/01/2019

print("Ingresa el radio de un circulo: ")

radio = input()

area = 3.141592653589793 * radio**2

print("Area: ", area)