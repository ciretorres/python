""" Title: Impares
	Author: Eric Torres
	UEA: Introducción a la programación
	Professor: Dra. Lizbeth Gallardo
	Description: Se desea imprimir en pantalla la serie de 
				números impares que existen en un rango de 
				1 a 10,000. 
	Update: 8/06/2019
"""
# -*- coding: utf-8 -*-

r = 1

while r <= 10000:
	if not r % 2 == 0:
		print(r)

	r = r + 1